package day4;
public class Sample403 {
    public static void main(String[] args) {
        int i = 0;
        while (i <= 5) {
            System.out.println(i+" ");
            i++;
        }
        System.out.println();
    }
}
