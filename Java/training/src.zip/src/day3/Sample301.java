package day3;

public class Sample301 {
    public static void main(String[] args) {
        int a = 10;
        System.out.println("a = " + a);
        if (a > 0){
            System.out.println("a is regular_number");
        }
        System.out.println(a > 0);
        System.out.println(a < 0);
    }
}
