package day3;

public class Sample302 {
    public static void main(String[] args) {
        int a = 10;
        System.out.println("a = " + a);
        if (a > 0){
            System.out.println("a is regular_number");
        }else{
            System.out.println("a is negative_number");
        }
    }
}
