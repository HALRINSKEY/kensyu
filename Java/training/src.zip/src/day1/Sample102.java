package day1;

public class Sample102 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		System.out.print(123);
		System.out.println(456);
		
		System.out.print("ABC");
		System.out.println("DEF");
		
		System.out.print("日本語");
		System.out.println("を表示");
	}

}
