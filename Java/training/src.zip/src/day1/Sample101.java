package day1;

public class Sample101 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("Hello,World");
	}

}
