package day2;

public class Sample201 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		System.out.print(5 + " + " +  2 + " = ");
		System.out.println(5 + 2);

		System.out.print(5 + " - " +  2 + " = ");
		System.out.println(5 - 2);
		
		System.out.print(5 + " * " +  2 + " = ");
		System.out.println(5 * 2);
		
		System.out.print(5 + " / " +  2 + " = ");
		System.out.println(5 / 2);

		System.out.print(5 + " % " +  2 + " = ");
		System.out.println(5 % 2);
		
		

	}

}
