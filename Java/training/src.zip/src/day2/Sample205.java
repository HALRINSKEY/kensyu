package day2;

public class Sample205 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		String s1,s2,s3;
		s1 = "ABC";
		s2 = "DEF";
		s3 = s1 + s2;
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1 + s2);
		System.out.println(s3);
	}

}
