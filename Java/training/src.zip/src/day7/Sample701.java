package day7;

public class Sample701 {
    public static void main(String[] args) {
        SampleClass02 s = new SampleClass02();
        s.method2();

        s.method3();
    }
}
